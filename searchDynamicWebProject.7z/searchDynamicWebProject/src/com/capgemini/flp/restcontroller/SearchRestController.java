package com.capgemini.flp.restcontroller;

import java.util.ArrayList;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.flp.entity.MerchantEntity;
import com.capgemini.flp.entity.ProductEntity;
import com.capgemini.flp.entity.CustomerEntity;
import com.capgemini.flp.service.SearchServiceInterface;
@Configuration
@Controller
public class SearchRestController {
	
	@Autowired
	SearchServiceInterface service;
	
	@RequestMapping(value="/findMerchant")
	public ModelAndView findMerchantByName(@RequestParam String Name)
	{
		List<MerchantEntity> detailsList = new ArrayList<MerchantEntity>();
		detailsList = (List<MerchantEntity>) service.findMerchantByName(Name);
		return new ModelAndView("show","list",detailsList);
		
	}
	
	
	@RequestMapping("/findCustomer")
	public ModelAndView findCustomer(@RequestParam String customerName)
	{
		
		System.out.println("in controller");
		System.out.println(customerName);
		List<CustomerEntity> customerList = new ArrayList<CustomerEntity>();
		customerList = (List<CustomerEntity>) service.findCustomerByName(customerName);
		return new ModelAndView("show","cuslist",customerList);
		
	}
	
	
	@RequestMapping(value="/findAllProducts")
	public ModelAndView findAllProducts(@RequestParam String merchantId)
	{
		List<ProductEntity> productsList = new ArrayList<ProductEntity>();
		productsList = (List<ProductEntity>) service.findAllProducts(merchantId);
		return new ModelAndView("show","productslist",productsList);
		
	}
	
	
	@RequestMapping(value="/findProducts")
	public ModelAndView findProducts(@RequestParam String productName)
	{
		System.out.println("in find products");
		List<ProductEntity> productsList = new ArrayList<ProductEntity>();
		productsList = (List<ProductEntity>) service.findProducts(productName);
		return new ModelAndView("show","productslist",productsList);
		
	}
	
	
	

}
