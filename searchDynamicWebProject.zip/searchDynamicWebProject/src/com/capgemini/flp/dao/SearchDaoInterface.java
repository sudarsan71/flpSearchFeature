package com.capgemini.flp.dao;

import java.util.List;






import com.capgemini.flp.entity.CustomerEntity;
import com.capgemini.flp.entity.MerchantEntity;
import com.capgemini.flp.entity.ProductEntity;

public interface SearchDaoInterface {
	
	public List<CustomerEntity> findCustomerByName(String name);
	public List<MerchantEntity> findMerchantByName(String merchantName);
	public List<ProductEntity> findProducts(String userData);
	public List<ProductEntity> findAllProducts(String merchantId);

}
