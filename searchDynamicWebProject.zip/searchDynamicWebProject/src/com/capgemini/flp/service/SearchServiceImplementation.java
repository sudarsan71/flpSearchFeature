package com.capgemini.flp.service;

import java.util.List;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.flp.dao.SearchDaoInterface;
import com.capgemini.flp.entity.MerchantEntity;
import com.capgemini.flp.entity.ProductEntity;
import com.capgemini.flp.entity.CustomerEntity;
@Configuration
@Transactional
@Service
public class SearchServiceImplementation implements SearchServiceInterface{

	@Autowired
	SearchDaoInterface dao;
	
	
	@Override
	public List<CustomerEntity> findCustomerByName(String name) {
		
		return dao.findCustomerByName(name);
		
	}

	@Override
	public List<MerchantEntity> findMerchantByName(String merchantName) {
		
		return dao.findMerchantByName(merchantName);
		
	}

	@Override
	public List<ProductEntity> findProducts(String userData) {
		
		return dao.findProducts(userData);
		
	}

	@Override
	public List<ProductEntity> findAllProducts(String merchantId) {
		// TODO Auto-generated method stub
		return dao.findAllProducts(merchantId);
	}

	
	
	

}
